// export const ENDPOINT_GET_POSTS = 'https://jsonplaceholder.typicode.com/todos';

export default {
  ENDPOINT_GET_POSTS: 'https://jsonplaceholder.typicode.com/todos',
}
