import React from 'react'
import { styled } from '@mui/material/styles';
import { Box, Paper, Grid } from '@mui/material';

import { connect } from 'react-redux';
import { set_trend_panel_data } from '@/src/actions';
import { bindActionCreators } from 'redux';

import { SET_TREND_PANEL_DATA } from '@/src/constants';

import Dashboard from '@/src/components/dashboard/Dashboard';
import Appbar from '@/src/components/dashboard/Appbar';
import Navbar from '@/src/components/dashboard/Navbar';



const Index = ({
  trendPanelData,
  actions: {
    set_trend_panel_data,
  }
}) => {
  return (
    <container>
      <Box>
        <Grid container>
          <Grid item xs={12} md={12} lg={12}>
            <Appbar />
          </Grid>
        </Grid>
      </Box>
    </container>
  )
}

Index.getInitialProps = async ({ store }) => {
  await store.dispatch(set_trend_panel_data())
  return {}
}

export default connect(
  state => state,
  dispatch => ({ actions: bindActionCreators({ set_trend_panel_data }, dispatch) })
)(Index)
