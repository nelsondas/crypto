import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
import ArrowDownwardOutlinedIcon from '@mui/icons-material/ArrowDownwardOutlined';
import Typography from '@mui/material/Typography';
import { useTheme, ThemeProvider, createTheme } from '@mui/material/styles';
import SignalCellularAltOutlinedIcon from '@mui/icons-material/SignalCellularAltOutlined';

function createData( pair,price, hour, volume) {
  return { pair, price, hour, volume };
}

const rows = [
  createData('XTZUSD', 12, 6.0, 24),
  createData('ADAUSD', 1.234, 9.0, 37),
  createData('ETHUSD', 2.912, 16.0, 24),
  createData('LINKUSD', 305, 3.7, 67),
];



export default function Topcoin() {
  const theme = useTheme();
  const tHeadColor = (theme.palette.mode == 'dark') ? "#182F4B" : "blue";
  return (
    <>
      <Container style={{ padding: "1rem" }}> 
        <Grid>
          <TableContainer component={Paper} style={{ padding: "1rem" }}>
            <Typography variant="subtitle1" gutterBottom style={{ display:"flex", alignItem:"center", justifyContent:"center", textAlign:"center", fontWeight:600 }}>
              <SignalCellularAltOutlinedIcon style={{ marginRight: "10px" }}/>
              SIGNAL
            </Typography>
              <Table aria-label="simple table">
                <TableHead style={{ background: tHeadColor }}>
                  <TableRow>
                    <TableCell style={{color:"warning", borderBottom:""}}>Pair</TableCell>
                    <TableCell style={{color:"primary", borderBottom:""}}>Signal</TableCell>
                    <TableCell style={{color:"primary", borderBottom:""}}>Price</TableCell>
                    <TableCell style={{color:"primary", borderBottom:""}}>Volume</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow
                      key={row.pair}
                      sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    >
                      <TableCell component="th" scope="row" style={{color:"#fff"}}>
                        {row.pair}
                      </TableCell>
                      <TableCell style={{color:"#fff",}}>{row.price}</TableCell>
                      <TableCell style={{color:"#fff",}}>{row.hour}</TableCell>
                      <TableCell style={{color:"#fff",}}>{row.volume}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
        </Grid>
      </Container>
    </>
  );
}
