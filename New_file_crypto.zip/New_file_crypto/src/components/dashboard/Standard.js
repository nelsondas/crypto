import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { FormControl } from '@mui/material';
import ScrollableTabsButtonVisible from './Scannermenulist';
import { InputLabel } from '@mui/material';
import { Select, MenuItem } from '@mui/material';
import ShareIcon from '@mui/icons-material/Share';
import DownloadIcon from '@mui/icons-material/Download';
import ScannerDataTable from './Scannertable';
import RadarOutlinedIcon from '@mui/icons-material/RadarOutlined';

const Item = styled(Paper)(({ theme }) => ({
  // backgroundColor: theme.palette.mode === 'dark' ? '' : '',
  // ...theme.typography.body2,
  // padding: theme.spacing(0),
  // textAlign: 'center',
  // color: theme.palette.text.secondary,
}));

const Standard = ()=> {
    const [age, setAge] = React.useState('');
    const handleChangee = (event) => {
      setAge(event.target.value);
    };
     const [exchange, setexchangee] = React.useState('');
     const [pair, setpair] = React.useState('');
    const handleChangeone = (event) => {
      setexchangee(event.target.value);
    };
    const handleChangesec = (event) => {
      setpair(event.target.value);
    };
  
    const [value, setValue] = React.useState(0);
  
    const handleChange = (event, newValue) => {
      setValue(newValue);
    };
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={12} md={6} lg={2}>
            <h2 style={{margin:"0rem"}}> <RadarOutlinedIcon /> Scanner</h2>
        </Grid>
        <Grid item xs={12} md={6} lg={7}>
            <ScrollableTabsButtonVisible />
        </Grid>
        {/* Dropdown section */}
        <Grid item xs={12} md={6} lg={3}>
      <FormControl variant="standard" sx={{minWidth: 100 }}>
        <InputLabel id="demo-simple-select-standard-label">Pair</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value={10}>All</MenuItem>
          <MenuItem value={20}>BTC</MenuItem>
          <MenuItem value={30}>USDT</MenuItem>
        </Select>
      </FormControl>
      <FormControl variant="standard" sx={{ minWidth: 100}}>
        <InputLabel id="demo-simple-select-standard-label">Exchange</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value={10}>Binance</MenuItem>
          <MenuItem value={20}>FTX</MenuItem>
        </Select>
      </FormControl>
      <div className='download_icon' style={{    display: "inline-flex",
    height: "73px",
    alignItems: "center",
    marginLeft: "60px",
    width: "60px",
    justifyContent: "space-between",}}>
      <DownloadIcon />
      <ShareIcon/>  
      </div>
      </Grid>
        </Grid>
        {/* Scanner table */}
        <Grid container spacing={2}>
        <Grid item xs={12} md={12} lg={12}>
            <ScannerDataTable />
            </Grid>
        </Grid>
    </Box>
  );
}
export default Standard;
