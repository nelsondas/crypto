import { createMuiTheme } from '@material-ui/core/styles'

const theme = createMuiTheme({
  palette: {
    // Customize Material-UI with your theme
    // See more here: https://material-ui.com/customization/themes/
  }
})

export default theme
