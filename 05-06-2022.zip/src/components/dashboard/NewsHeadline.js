import React from 'react';
import PropTypes from 'prop-types';
import { Grid, Paper, Box, Typography, Item } from '@mui/material';
import Stack from '@mui/material/Stack';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';

const NewsHeadline = (props) => {
  return (
    <Box>
      <Paper>
      <div style={{ display: 'flex', padding:"1rem"}}>
      <Stack
        direction={{ xs: 'column', sm: 'row' }}
        spacing={{ xs: 1, sm: 2, md: 4 }}
        style={{margin:'0px 20px 0px 0px'}}
      >
      <Typography>
        ETHUSD gained 21% <ArrowUpwardIcon fontSize="x-small" /> since last signal
      </Typography>
      </Stack>
      <Stack
        direction={{ xs: 'column', sm: 'row' }}
        spacing={{ xs: 1, sm: 2, md: 4 }}
        style={{margin:'0px 20px 0px 0px'}}
      >
      <Typography>
      BTCUSD increased by 21% <ArrowUpwardIcon fontSize="x-small" /> in price since last signal
      </Typography>
      </Stack>
      <Stack
        direction={{ xs: 'column', sm: 'row' }}
        spacing={{ xs: 1, sm: 2, md: 4 }}
        style={{margin:'0px 20px 0px 0px'}}
      >
      <Typography>
        ETHUSD gained 21% <ArrowUpwardIcon fontSize="x-small" /> since last signal
      </Typography>
      </Stack>
      <Stack
        direction={{ xs: 'column', sm: 'row' }}
        spacing={{ xs: 1, sm: 2, md: 4 }}
        style={{margin:'0px 20px 0px 0px'}}
      >
      <Typography>
      BTCUSD increased by 21% <ArrowUpwardIcon fontSize="x-small" /> in price since last signal
      </Typography>
      </Stack>
 
    </div>
      </Paper>
    </Box>
  )
}

export default NewsHeadline;
