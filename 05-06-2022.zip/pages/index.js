import React from 'react'

import Layout from '@/src/components/layout/Layout';


const Index = () => {
  return (
    <div>
      <Layout />
    </div>
  )
}

export default Index
