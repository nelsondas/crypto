import * as React from 'react';
import Grid from '@mui/material/Grid';
import Tabss from './Tabss';

export default function Scannerbutton() {
  const [value, setValue] = React.useState(2);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    
    <Grid container spacing={2}>
     
      <Grid item xs={12}>
      <Tabss/>
      
      </Grid>

      </Grid>
  );
}